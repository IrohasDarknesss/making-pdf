import img2pdf
import glob
from natsort import natsorted #自然順にするため

# 画像一覧を取得
lists = list(glob.glob("C:/Users/kaine/Desktop/house/imgs/png2jpg/*.jpg"))

# PDFファイルを出力
pdfpath = "house.pdf"
with open(pdfpath,"wb") as f:
    f.write(img2pdf.convert([str(i) for i in natsorted(lists) if ".jpg" in i]))
